import sys
sys.path.append("./CLIP")
from clip import *
